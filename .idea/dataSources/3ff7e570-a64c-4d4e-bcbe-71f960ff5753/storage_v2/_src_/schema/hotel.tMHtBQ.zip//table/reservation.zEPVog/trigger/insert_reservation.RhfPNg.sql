create definer = root@localhost trigger insert_reservation
    before insert
    on reservation
    for each row
BEGIN
	if (SELECT COUNT(*) FROM reservation, chambre, hotel
	WHERE res_cha_id = cha_id
	AND cha_hot_id = hot_id) >10
	then SIGNAL SQLSTATE '40000' SET MESSAGE_TEXT = 'impossible total chambre dépassée ';
	END if;
END;

