create view v_hotel_sta as
select `hotel`.`hotel`.`hot_nom` AS `hot_nom`, `hotel`.`station`.`sta_nom` AS `sta_nom`
from `hotel`.`hotel`
         join `hotel`.`station`
where `hotel`.`hotel`.`hot_sta_id` = `hotel`.`station`.`sta_id`;

