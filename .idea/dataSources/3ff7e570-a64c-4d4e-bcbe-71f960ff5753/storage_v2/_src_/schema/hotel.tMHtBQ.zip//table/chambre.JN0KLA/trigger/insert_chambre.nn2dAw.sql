create definer = root@localhost trigger insert_chambre
    before insert
    on chambre
    for each row
BEGIN
	if (SELECT count(cha_id) FROM chambre
	WHERE cha_hot_id = 1) >50
	then SIGNAL SQLSTATE '40000' SET MESSAGE_TEXT = 'impossible le total de chambres enregistrées est dépassées';
	END if;
END;

